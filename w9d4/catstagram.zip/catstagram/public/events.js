
window.addEventListener('DOMContentLoaded', function(){
    loadCatPic();
    document.getElementById("new-pic").addEventListener("click", loadCatPic);
    document.getElementById("upvote").addEventListener("click", upvote);
    document.getElementById("downvote").addEventListener("click", downvote);
    document.querySelector(".comment-form").addEventListener("submit", submitComment);
});

const loadCatPic = async () => {
    const loader = document.querySelector('.loader')
    loader.innerHTML = 'Loading...';

    const initialResponse = await fetch('/kitten/image');
    if (initialResponse.ok) {
        const data = await initialResponse.json();
        loader.innerHTML = "";
        document.querySelector('.cat-pic').src = data.src;
        document.querySelector('.score').innerHTML = data.score;
        document.querySelector('.comments').innerHTML = '';
    } else {
        alert("503 Server Error")
    }   
}

const upvote = async () => {
    const initialResponse = await fetch('/kitten/upvote', 
        {
            method: "PATCH"
        }
    );
     
    const jsonResponse = await initialResponse.json();
    const score = jsonResponse.score;
    
    const scoreElement = document.querySelector(".score");
    scoreElement.innerHTML = score;
}

const downvote = async () => {
    const initialResponse = await fetch('/kitten/downvote',
        {
            method: "PATCH"
        }
    );
    const { score } = await initialResponse.json();
    const scoreElement = document.querySelector(".score");
    scoreElement.innerHTML = score;
}

const submitComment = async (e) => {
    e.preventDefault();
    const comment = document.getElementById("user-comment").value;
    const initialResponse = await fetch('/kitten/comments',
        {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({comment})
        }
    )
    const commentsJSONResponse = await initialResponse.json();
    const comments = document.querySelector('.comments');
    const newComment = document.createElement("div");
    newComment.innerHTML = commentsJSONResponse.comments[commentsJSONResponse.comments.length - 1];
    comments.appendChild(newComment);
}