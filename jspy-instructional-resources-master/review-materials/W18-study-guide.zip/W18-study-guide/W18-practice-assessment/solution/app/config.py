class Configuration:
    SQLALCHEMY_DATABASE_URI = "postgresql://pyweb_practice_user:pyweb@localhost/pyweb_practice_db"
    SECRET_KEY = "klisafluiasdfiuh"
