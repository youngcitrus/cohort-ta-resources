import React from 'react';
import { Switch, NavLink } from 'react-router-dom';

import RegistrationForm from './components/session/RegistrationForm';
import Home from './components/Home';
import LoginForm from './components/session/LoginForm';
import Profile from './components/Profile';
import { ProtectedRoute, AuthRoute } from './Routes';

const App = (props) => (
	<div>
		<h1>Twitter Lite</h1>
		<nav>
			<NavLink exact to='/'>
				Home
			</NavLink>
			<NavLink to='/register'>Register</NavLink>
			<NavLink to='/login'>Login</NavLink>
			{props.currentUserId ? <NavLink to={`/users/${props.currentUserId}`}>My Profile</NavLink> : null}
		</nav>
		<Switch>
			<ProtectedRoute exact path='/' component={Home} currentUserId={props.currentUserId} />
			<AuthRoute path='/register' component={RegistrationForm} currentUserId={props.currentUserId} />
			<AuthRoute path='/login' component={LoginForm} currentUserId={props.currentUserId} />
			<ProtectedRoute path='/users/:userId' component={Profile} currentUserId={props.currentUserId} />
		</Switch>
	</div>
);

export default App;
