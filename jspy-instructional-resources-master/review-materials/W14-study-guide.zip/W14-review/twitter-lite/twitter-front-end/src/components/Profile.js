import React from 'react';

import UserContext from '../contexts/UserContext';
import { apiBaseUrl } from '../config';
// import withContext from '../contexts/withContext';

class Profile extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			user: {},
			tweets: []
		};
	}

	async componentDidMount() {
		// TODO: Fetch user and their tweets
		try {
			const userRes = await fetch(`${apiBaseUrl}/users/${this.props.match.params.userId}`, {
				headers: {
					Authorization: `Bearer ${this.props.authToken}`
				}
			});

			if (!userRes.ok) {
				throw userRes;
			}

			const userData = await userRes.json();
			console.log(userData);

			const tweetRes = await fetch(`${apiBaseUrl}/users/${this.props.match.params.userId}/tweets`, {
				headers: {
					Authorization: `Bearer ${this.props.authToken}`
				}
			});

			if (!tweetRes.ok) {
				throw tweetRes;
			}

			const tweetData = await tweetRes.json();
			console.log(tweetData);
			this.setState({ tweets: tweetData.tweets, user: userData.user });
		} catch (err) {
			console.error(err);
		}
	}

	render() {
		return (
			<div>
				<h1>{this.state.user.username}'s Profile Page</h1>
				<ul>
					{this.state.tweets.map((tweet) => {
						const { id, message } = tweet;
						return (
							<li key={id}>
								<h3>{this.state.user.username}</h3>
								<p>{message}</p>
							</li>
						);
					})}
				</ul>
			</div>
		);
	}
}

// Bonus Phase: Replacing Consumer components with our withContext function
// export default withContext(Profile);

const ProfileWithContext = (props) => (
	<UserContext.Consumer>
		{(value) => <Profile authToken={value.authToken} currentUserId={value.currentUserId} {...props} />}
	</UserContext.Consumer>
);

export default ProfileWithContext;
