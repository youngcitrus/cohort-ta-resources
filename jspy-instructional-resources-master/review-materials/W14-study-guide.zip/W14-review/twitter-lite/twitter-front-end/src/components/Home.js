import React from 'react';

import UserContext from '../contexts/UserContext';
import { apiBaseUrl } from '../config';

class Home extends React.Component {
	constructor(props) {
		super(props);
		// TODO: Set up default state
		this.state = {
			tweets: [],
			message: ''
		};
	}
	static contextType = UserContext;

	async componentDidMount() {
		// TODO: Fetch tweets
		try {
			const res = await fetch(`${apiBaseUrl}/tweets`, {
				headers: {
					Authorization: `Bearer ${this.context.authToken}`
				}
			});

			if (!res.ok) {
				throw res;
			}
			const data = await res.json();
			this.setState({ tweets: data.tweets });
		} catch (err) {
			console.error(err);
		}
	}

	logoutUser = () => {
		this.context.logout();
	};

	handleChange = (e) => {
		this.setState({ [e.target.name]: e.target.value });
	};

	createTweet = async (e) => {
		e.preventDefault();
		const newTweet = { message: this.state.message, userId: this.context.currentUserId };
		try {
			const res = await fetch(`${apiBaseUrl}/tweets`, {
				method: 'POST',
				headers: {
					Authorization: `Bearer ${this.context.authToken}`,
					'Content-Type': 'application/json'
				},
				body: JSON.stringify(newTweet)
			});

			if (!res.ok) {
				throw res;
			}
			const data = await res.json();
			console.log(this.state);
			console.log(data);
			const returnedTweet = {
				id: data.tweet.id,
				message: data.tweet.message,
				user: { id: data.user.id, username: data.user.username }
			};
			this.setState({ tweets: [ returnedTweet, ...this.state.tweets ] });
		} catch (err) {
			console.error(err);
		}
	};

	deleteTweet = async (e) => {
		const tweetId = parseInt(e.target.name);
		try {
			const res = await fetch(`${apiBaseUrl}/tweets/${tweetId}`, {
				method: 'DELETE',
				headers: {
					Authorization: `Bearer ${this.context.authToken}`
				}
			});

			if (!res.ok) {
				throw res;
			}
			const newTweets = this.state.tweets.filter((tweet) => tweet.id !== tweetId);
			this.setState({ tweets: newTweets });
		} catch (err) {
			console.error(err);
		}
	};

	render() {
		return (
			<div>
				<h1>Home Page</h1>
				<button onClick={this.logoutUser}>Log Out</button>

				<form>
					<h2>Create a Tweet</h2>
					<textarea
						name='message'
						placeholder='Enter your Tweet'
						value={this.state.message}
						onChange={this.handleChange}
					/>
					<button type='submit' onClick={this.createTweet}>
						Submit Tweet
					</button>
				</form>

				<ul>
					{this.state.tweets.map((tweet) => {
						const { id, message, user: { username } } = tweet;
						const ownTweet = tweet.user.id === parseInt(this.context.currentUserId);
						return (
							<li key={id}>
								<h3>{username}</h3>
								<p>{message}</p>
								{ownTweet ? (
									<button name={id} onClick={this.deleteTweet}>
										Delete Tweet
									</button>
								) : null}
							</li>
						);
					})}
				</ul>
			</div>
		);
	}
}

export default Home;
