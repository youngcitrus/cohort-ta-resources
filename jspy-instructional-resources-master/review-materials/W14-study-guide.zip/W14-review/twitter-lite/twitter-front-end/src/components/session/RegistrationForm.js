import React from 'react';

import { apiBaseUrl } from '../../config';
// import UserContext from '../../contexts/UserContext';
import withContext from '../../contexts/withContext';

class RegistrationForm extends React.Component {
	constructor(props) {
		super(props);
		// TODO: Set up default state
		this.state = {
			username: '',
			email: '',
			password: ''
		};
	}

	handleChange = (e) => {
		this.setState({ [e.target.name]: e.target.value });
	};

	registerUser = async (e) => {
		e.preventDefault();
		const body = JSON.stringify(this.state);
		try {
			const res = await fetch(`${apiBaseUrl}/users`, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				body
			});

			if (!res.ok) {
				throw res;
			}
			const { token, user: { id } } = await res.json();
			this.props.login(token, id);
		} catch (err) {
			const { errors } = await err.json();
			console.log(errors);
		}
	};

	render() {
		const { username, email, password } = this.state;
		return (
			<form>
				<h2>Register</h2>
				<div>
					<label htmlFor='username'>Username</label>
					<input
						type='text'
						name='username'
						placeholder='Enter Username'
						value={username}
						onChange={this.handleChange}
					/>
				</div>
				<div>
					<label htmlFor='email'>Email</label>
					<input type='email' name='email' placeholder='Enter Email' value={email} onChange={this.handleChange} />
				</div>
				<div>
					<label htmlFor='password'>Password</label>
					<input
						type='password'
						name='password'
						placeholder='Enter Password'
						value={password}
						onChange={this.handleChange}
					/>
				</div>
				<button type='submit' onClick={this.registerUser}>
					Sign Up
				</button>
			</form>
		);
	}
}

// // Bonus Phase: Replacing Consumer components with our withContext function

// const RegistrationFormWithContext = (props) => (
// 	<UserContext.Consumer>{(value) => <RegistrationForm login={value.login} {...props} />}</UserContext.Consumer>
// );

// export default RegistrationFormWithContext;

export default withContext(RegistrationForm);
