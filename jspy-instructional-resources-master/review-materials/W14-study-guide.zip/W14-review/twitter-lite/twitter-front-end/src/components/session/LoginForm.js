import React from 'react';

import { apiBaseUrl } from '../../config';
// import UserContext from '../../contexts/UserContext';
import withContext from '../../contexts/withContext';

class LoginForm extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			email: '',
			password: ''
		};
	}

	handleChange = (e) => {
		this.setState({ [e.target.name]: e.target.value });
	};

	loginUser = async (e) => {
		e.preventDefault();
		const body = JSON.stringify(this.state);
		try {
			const res = await fetch(`${apiBaseUrl}/users/token`, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				body
			});

			if (!res.ok) {
				throw res;
			}

			const { token, user: { id } } = await res.json();
			this.props.login(token, id);
		} catch (err) {
			console.log(err);
		}
	};

	render() {
		const { email, password } = this.state;
		return (
			<form>
				<h2>Log In</h2>
				<div>
					<label htmlFor='email'>Email</label>
					<input type='email' name='email' placeholder='Enter Email' value={email} onChange={this.handleChange} />
				</div>
				<div>
					<label htmlFor='password'>Password</label>
					<input
						type='password'
						name='password'
						placeholder='Enter Password'
						value={password}
						onChange={this.handleChange}
					/>
				</div>
				<button type='submit' onClick={this.loginUser}>
					Log In
				</button>
			</form>
		);
	}
}

// Bonus Phase: Replacing Consumer components with our withContext function

// const LoginFormWithContext = (props) => (
// 	<UserContext.Consumer>{(value) => <LoginForm login={value.login} {...props} />}</UserContext.Consumer>
// );

// export default LoginFormWithContext;

export default withContext(LoginForm);
