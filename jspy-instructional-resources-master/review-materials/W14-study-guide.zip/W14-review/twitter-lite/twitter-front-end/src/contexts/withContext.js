import React from 'react';
import UserContext from './UserContext';

const withContext = (Component) => {
	return function ContextComponent(props) {
		return <UserContext.Consumer>{(value) => <Component {...props} {...value} />}</UserContext.Consumer>;
	};
};

export default withContext;
