INSERT INTO users (full_name, created_at)
VALUES
('Zaphod Beeblebrox', CURRENT_TIMESTAMP),
('Blart Versenwald III', CURRENT_TIMESTAMP)
