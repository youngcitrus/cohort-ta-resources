INSERT INTO merchant_types(type)
VALUES
('Retail'),
('Wholesale')
