INSERT INTO merchants (merchant_name, country_id, created_at, admin_id, merchant_type_id)
VALUES
('Zingo', 1, CURRENT_TIMESTAMP, 1, 1),
('Widgets International', 2, CURRENT_TIMESTAMP, 2, 2),
('Snglrify', 3, CURRENT_TIMESTAMP, 1, 1),
('Better Products 4 U', 3, CURRENT_TIMESTAMP, 1, 2)
