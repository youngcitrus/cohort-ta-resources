CREATE TABLE countries (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  continent_name VARCHAR(20) NOT NULL
)
