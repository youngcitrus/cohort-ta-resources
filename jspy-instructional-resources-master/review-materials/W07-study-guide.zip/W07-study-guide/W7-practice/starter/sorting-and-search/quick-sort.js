function quickSort(array) {}
