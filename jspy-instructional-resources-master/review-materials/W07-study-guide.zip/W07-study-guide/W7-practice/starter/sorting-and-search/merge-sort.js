function mergeSort(array) {}

// A merge helper function may be helpful in implementing the sort function above
function merge(array1, array2) {}
