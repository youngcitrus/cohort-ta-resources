class Node {
	constructor(val) {
		this.value = val;
		this.next = null;
	}
}

class Queue {
	constructor() {}

	enqueue(val) {}

	dequeue() {}

	size() {}
}
