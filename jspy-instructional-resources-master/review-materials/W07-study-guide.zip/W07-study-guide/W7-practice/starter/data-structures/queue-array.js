class QueueArray {
	constructor() {}

	enqueue(value) {}

	dequeue() {}

	peek() {}
}
