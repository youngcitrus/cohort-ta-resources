// Create an Employee class that takes in a name and department
// Add an introduceSelf method that prints "Hi, I'm <<name>>. I work in <<department>>."

// Export the Employee class using CommonJS so that we don't have to destructure later on.
