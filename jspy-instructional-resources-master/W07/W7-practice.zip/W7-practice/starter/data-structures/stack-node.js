class Node {
	constructor(value) {
		this.value = value;
		this.next = null;
	}
}

class StackNode {
	constructor() {}

	push(val) {}

	pop() {}

	peek() {}

	size() {}
}
