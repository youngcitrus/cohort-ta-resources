class StackArray {
	constructor() {}

	push(value) {}

	pop() {}

	peek() {}
}
