class Node {
	constructor(val) {
		this.value = val;
		this.next = null;
		this.previous = null;
	}
}

class LinkedList {
	constructor() {}

	addToTail(val) {}

	removeTail() {}

	addToHead(val) {}

	removeHead() {}

	contains(target) {}

	get(index) {}

	set(index, val) {}

	insert(index, val) {}

	remove(index) {}

	size() {}

	peakHead() {}

	peakTail() {}
}
