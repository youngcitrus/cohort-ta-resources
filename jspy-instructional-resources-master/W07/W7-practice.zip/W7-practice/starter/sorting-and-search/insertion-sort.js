function insertionSort(arr) {}
