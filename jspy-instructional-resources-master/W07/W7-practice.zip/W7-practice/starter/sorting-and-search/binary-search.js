// Create a binary search that returns a boolean for whether the target exists
// in the array. (Try implementing with both recursion and iteration!)
function binarySearch(array, target) {}

// Create a binary search that returns the index of the target if it exists
// in the array and -1 if not. (Try implementing with both recursion and iteration!)
function binarySearchIndex(array, target) {}
