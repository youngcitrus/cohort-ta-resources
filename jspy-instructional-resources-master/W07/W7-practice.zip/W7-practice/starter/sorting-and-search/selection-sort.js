function selectionSort(arr) {}

// A swap helper function may be useful to implement the sort function above
function swap(arr, index1, index2) {}
