function bubbleSort(array) {}

// A swap helper function may be useful to implement the sort function above
function swap(array, idx1, idx2) {}
