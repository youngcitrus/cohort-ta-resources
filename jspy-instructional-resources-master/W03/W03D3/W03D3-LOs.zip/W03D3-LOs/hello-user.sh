#!/bin/bash

# "Hello, $USER!" by Bryce Morgan
#
# Greets the current user in the terminal

echo "Hello, $USER!"