## Group 1 - 20 minutes
  - 01 Python Basics (7:06)
  - 02 Number Types (9:00)
## Group 2 - 25 minutes
  - 03 Simple Formatted Strings (10:19)
  - 04 Duck Typing (7:26)
    - Complex Try Blocks
  - 05 Arithmetic with Strings (3:36)
    - Extra String Operations
## Group 3 - 40 minutes
  - 06 Assignment Operators (9:17)
  - 07 The Meaning of Truth (13:22)
    - Logical Operators
    - While Loops
  - 08 Identity vs. Equality Demo (10:50)
## Group 4 - 14 minutes
  - 09 Functions in Python (8:28)
  - 10 Functions Returning Functions (2:00)
