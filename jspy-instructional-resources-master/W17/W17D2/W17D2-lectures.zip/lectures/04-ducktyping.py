# Duck Typing
# - len()
# - try ... except

a = False
try:
    print(len(a))
except:
    print(f'{a} has no length')
