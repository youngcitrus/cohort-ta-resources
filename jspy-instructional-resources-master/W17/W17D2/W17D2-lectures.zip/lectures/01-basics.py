# Basics of Python
# - single, double and triple quotes
# - shortcut for code comment (Mac: command+/ or Windows: control+/)
# - printing variables
# - None

print('Hello, World')
print("It's raining!")
print('''
Welcome to Python
Have a great day!!!
''')

a = None
print(a)
